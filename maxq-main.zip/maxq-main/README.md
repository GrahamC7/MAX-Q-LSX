# maxq
First attempt at building a landing page on my own.

https://cockerhamsg.github.io/maxq/
